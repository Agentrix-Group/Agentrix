#!/usr/bin/env python3
"""Starfighter Starter Bot -- Reference Bot for Agentrix (ATD-007)."""
import json
import sys


def send(msg: dict) -> None:
    sys.stdout.write(json.dumps(msg) + "\n")
    sys.stdout.flush()


def read() -> dict:
    line = sys.stdin.readline()
    if not line:
        sys.exit(0)
    return json.loads(line)


def choose_action(perception: dict) -> dict:
    # A standard baseline action for tick 0 and subsequent ticks
    return {
        "thrust": "FORWARD",
        "turn": "NONE",
        "shoot": False,
        "shield": False,
    }


def main() -> None:
    # Read init handshake
    init = read()
    assert init["type"] == "init"

    while True:
        msg = read()
        if msg["type"] == "end":
            break
        if msg["type"] == "perception":
            action = choose_action(msg)
            send({"type": "action", "tick": msg["tick"], "action": action})


if __name__ == "__main__":
    main()
